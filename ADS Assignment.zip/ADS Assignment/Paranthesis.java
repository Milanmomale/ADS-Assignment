package Practice;
import java.util.Scanner;
class Paranthesis
{
    int size=5;
    char arr[]=new char[size];
    int top;

    Paranthesis() { top = -1; }
    
    boolean isEmpty(){ return (top<0); }
    boolean isFull(){ return(top>=size); }
    
    
    void push(char data)
    {
        if (isFull())
        {
            System.out.println("Stack is Full");
        }
        else
        {
            top++;
            arr[top]=data;
         }
    }
    
    char pop()
    {
        if(isEmpty())
        {
            System.out.println("Stack is empty");
            return 0;
        }
        else
        {
            char data=arr[top--];
            return data;
        }
       
    }
    
    char peek()
    {
        if(isEmpty())
        {
            System.out.println("Stack is empty");
            return 0;
        }
        else
        {
            char data=arr[top];
            return data;
        }
    }
    
    boolean isBalanced(String str)
    {
        for(int i=0;i<str.length();i++)
        {
            char c=str.charAt(i);
             if((c=='(') || (c=='[') || (c=='{') )
             {
                 push(c);
             }
             if(isEmpty())
                 return false;
             
             switch(c)
             {
                 case ')':
                    if(peek()=='(')
                     pop();
                         break;
                case ']':
                     if(peek()=='[')
                     pop();
                         break;
               case '}':
                     if(peek()=='{')
                     pop();
                         break;      
                       
             }
        }
       return isEmpty();
    }
  
    public static void main(String[] args)
    {
      Scanner  sc =new Scanner(System.in);
      Paranthesis p=new Paranthesis();
      System.out.println("Enetr you brackets :");
      String str=sc.nextLine();
      System.out.println("===================");
      if(p.isBalanced(str))
      {
          System.out.println("The given brackets are Balanced");
      }
      else
      {
          System.out.println("The given brackets are Not balanced");
      }
   }
}