package Day1;

import java.util.Scanner;

public class Stack2 {
	
	
	static int arr_size=10;
	
	int arr[]=new int[arr_size];
	int top;
	
	boolean isEmpty()
	{
		return (top<0);	
	}
	Stack2()
	{
		top=-1;
	}
	
	boolean push(int x)
	{
		if(top>arr_size-1)
		{
			System.out.println("Stack  OverFlow");
		
		return false;
		}
	
	else {
		 arr[++top]=x;
		 System.out.println(x+" :"+"Pushed into Stack");
		 	return true;
	}
	}
		int pop()
		{
			if(top<0)
				{
				System.out.println("Stack UnderFlow");
					return 0;
				}
			else
				{
                                 //   arr[top]=0;  <--to make that element zero
				int x=arr[top--];
				return x;
				}
		}
	int peek()
	{
		if(top<0)
		{
			System.out.println("Stack UnderFLow");
			return 0;
			
		}
		else{
			int x=arr[top];
			return x;
		}
	}
	
	
}