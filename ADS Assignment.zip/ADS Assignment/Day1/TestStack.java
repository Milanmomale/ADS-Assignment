package Day1;

public class TestStack {

	public static void main(String[] args) {
	
		Stack2 s1=new Stack2();
                System.out.println(s1.isEmpty());
		s1.push(100);
		s1.push(200);
		s1.push(300);
                s1.push(400);
	     System.out.println("peek on top:"+s1.peek());
		
          //  System.out.println( "popped out:"+s1.pop());
            System.out.println(  "popped out:"+s1.pop());
            System.out.println(  "popped out:"+s1.pop());
           
                System.out.println(s1.isEmpty());	     
	}

}