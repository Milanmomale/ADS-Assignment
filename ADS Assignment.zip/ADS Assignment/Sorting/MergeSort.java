package Sorting;

import java.util.Scanner;

class MergeSort 
{
    int arr[];
    int tempArr[];
    int length;
            public static void main(String[] args)
            {
                    MergeSort msort=new MergeSort();
                    int input[]=new int[3];
                    System.out.println("Enter elements:");
                    Scanner sc=new Scanner(System.in);
                    for(int i=0;i<input.length;i++)
                    {
                        input[i]=sc.nextInt();
                    }
                    msort.sort(input);
                    System.out.println("=============");
                    System.out.println("Sorted Output:");
                    for (int i=0;i<input.length;i++)
                    {
                        System.out.print(input[i]+" ");
                    }
            }

    private void sort(int input[])
    {
        this.arr=input;
        this.length=input.length;
        tempArr= new int [length];
        divideArr(0,length-1);
    }

    private void divideArr(int low, int high)
    {
        if (low<high)
        {
            int mid=(low+high)/2;
            divideArr(low, mid);// to sort left part
            divideArr(mid+1, high);//to sort right part
            mergeArr(low,mid,high);
        }
    }

    private void mergeArr(int low, int mid, int high)
    {
       
        for (int m=low;m<=high;m++)
        {
            tempArr[m]=arr[m];
        }
        
        int i=low;
        int j=mid+1;
        int k=low;
        while (i<=mid&&j<=high)
        {
            if (tempArr[i]<=tempArr[j])
            {
            arr[k]=tempArr[i];
            i++;
            }
            else
            {
                arr[k]=tempArr[j];
                j++;
            }
            k++;
        }
        
        while(i<=mid)
        {
            arr[k]=tempArr[i];
            i++;
            k++;
        }
    }
}