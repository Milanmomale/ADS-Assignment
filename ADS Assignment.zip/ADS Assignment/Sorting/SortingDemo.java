package Sorting;

import java.util.Scanner;

class SortingDemo
{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Sort b =new Sort();
        int arr[]=new int[3];
        System.out.println("Enter Array Elements:");
        for(int i=0;i<arr.length;i++)
        {
            arr[i]=sc.nextInt(); 
        }
        b.bubbleSort(arr);
        b.display(arr);
        b.insertionSort(arr);
        b.display(arr);
        b.selectionSort(arr);
        b.display(arr);
    }
}