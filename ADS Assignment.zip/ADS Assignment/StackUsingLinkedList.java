package Practice;
// Stack Using Linked list

import java.util.Scanner;

class StackUsingLinkedlist
{ 
	private class Node
	{ 
            int data;
            Node next; 
	} 
	
	Node top;
	StackUsingLinkedlist() 
	{ 
		this.top = null; 
	} 
 
	public void push(int x) 
	{
		Node newnode = new Node(); 
		if (newnode == null)
		System.out.println(" Overflow"); 
		newnode.data = x; 
		newnode.next = top; 
		top = newnode; 
	} 

	public boolean isEmpty() 
	{ 
		return top == null; 
	}
	
	public int peek() 
	{  
		if (!isEmpty())
		{ 
			return top.data; 
		} 
		else { 
			System.out.println("Stack is empty"); 
			return -1; 
		} 
	} 

	public void pop() 
	{ 
		if (top == null) { 
			System.out.print("\nStack Underflow"); 
			return; 
		} 
		top = top.next; 
	} 

	public void display() 
	{ 
		if (top == null)
		{ 
			System.out.println("Stack Underflow"); 
			return; 
		} 
		else { 
			Node temp = top; 
			while (temp != null) 
			{ 
				System.out.println(" "+temp.data); 
				temp = temp.next; 
			} 
		} 
	} 
        
	public static void main(String[] args) 
	{ 
	StackUsingLinkedlist obj = new StackUsingLinkedlist();
            Scanner sc=new Scanner(System.in);
            
            int n=sc.nextInt();
            for(int i=0;i<n;i++)
            {
                int a=sc.nextInt();
                obj.push(a);
            }
            obj.display();
            System.out.println("============");
            //displaying the stack elements
            for(int j=0;j<n;j++)
            {
                obj.pop();
            }
            
            obj.display();
		/*StackUsingLinkedlist obj = new StackUsingLinkedlist(); 
		
		obj.push(11); 
		obj.push(22); 
		obj.push(33); 
		obj.push(44); 
		obj.display(); 
		System.out.printf("\nTop element is %d\n", obj.peek()); 
		obj.pop(); 
		obj.pop(); 
		obj.display(); 
		System.out.printf("\nTop element is %d\n", obj.peek());*/ 
        } 
}