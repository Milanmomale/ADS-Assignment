package LinkedList;

import java.util.Scanner;

class LinkedList2
{
    Node head;
   
    void insertAtFirst(int data)
    {
        Node newnode =new Node(data);
        if(head==null)
        {
            head=newnode;  //if head is single node then make newnode is 
        }
        else
        {
        newnode.next=head;
        head=newnode;
        }
    }
    
    void insertAtMiddle(int pos,int d)
     {
         Node newnode=new Node(d);
         if(head==null)
        {
            head=newnode;
        }
         else{
         Node temp=head;
         for(int i=1;i<pos-1;i++)
         {
             temp=temp.next;
         }
         newnode.next=temp.next;
         temp.next=newnode;
     }
     }
    
    
    
    
  /* void insertAtMiddle(Node oldnode,int data)
    {
       
    if (oldnode == null)  
    {  
        System.out.println("old node is null");  
        return;  
    }
        Node newnode = new Node(data);  
        newnode.next = oldnode.next; 
        oldnode.next = newnode;
          
    }*/
    
    
    void insertAtLast(int data)
    {
        Node newnode = new Node(data);
   
            if (head == null) 
            { 
            head = newnode; 
            }
            else
            {
                Node n = head;  
                while (n.next != null) 
                {
                n = n.next; 
                }
                n.next = newnode;
            }
    }
    
    
    void printList()
    {
        Node temp=head;   //temp is important we can use it instead of head
        while(temp!=null)
        {
        System.out.println(temp.data);
        temp=temp.next;
        }
    }   
    
    void deleteAtBeg()
    {
        if(head==null)
        {
            System.out.println("List empty");
        }
        else
        {
           head=head.next;
        }
      
    }
 
    void deleteAtMiddle(int p)
    {
            if (head ==null)
            {
                System.out.println("List is empty");
            }
            else
            {
                Node temp=head;
                for (int i=1;i<p-1;i++)
                {
                    temp=temp.next;
                }temp.next=temp.next.next;
            }
           
    }
    
    void deleteAtEnd()
    {
        if(head==null)
        {
            System.out.println("List is empty");
        }
        else
        {
          Node temp=head;
          while(temp.next.next!=null)
          {
              temp=temp.next;
          }temp.next=null;
        }
    }
 
    
    
    public static void main(String[] args)
    {
        LinkedList2 l=new LinkedList2();
      /*  l.insertAtFirst(10);
        l.insertAtFirst(20);
        l.insertAtFirst(45);
        l.insertAtFirst(85);
        l.insertAtMiddle(l.head, 32);
        l.insertAtLast(1313);
        l.insertAtLast(2323);
        l.insertAtLast(3333);
        l.insertAtLast(4343);
        l.deleteAtBeg();
        l.deleteAtEnd();
        System.out.println("============================");
        System.out.println("After inserting all elements");
        l.printList();
        System.out.println("============================");
        l.printList();*/
        Scanner sc = new Scanner(System.in);
        String st[]={"1.Add to Front","2.Add to Middle","3.Add to Last","4.Delete First","5.Delete Middle","6.Delete Last","7.Display"};
        int choice;
       
    do{    
            for (String st1 : st) {
                System.out.println(st1);
            }
        System.out.println("Enter no. of operation :");
        choice=sc.nextInt();
        int a,b;
        switch(choice)
        {
            
            case 1:
                System.out.println("Enter element at first :");
                a=sc.nextInt();
                l.insertAtFirst(a);
                break;
            case 2:   
                System.out.println("Enter element at middle :");
                a=sc.nextInt();
                System.out.println("Enter position:");
                b=sc.nextInt();
                l.insertAtMiddle(b,a);
                break;
            case 3:
                System.out.println("Enter element at last:");
                a=sc.nextInt();
                l.insertAtLast(a);
                break;
            case 4:
                 l.deleteAtBeg();
                 break;
            case 5:
                System.out.println("Enter position:");
                b=sc.nextInt();
                l.deleteAtMiddle(b);
                break;
            case 6:
                l.deleteAtEnd();
                break;
            case 7:
                l.printList();
                break;
                
            default:System.out.println("Not valid operation");
        }
    }while(choice!=8);
    } 
    
}