package LinkedList;

class Node 
{
    int data;
    Node next;
    Node(int data)
    {
        this.data=data;
        next=null;
    }
}