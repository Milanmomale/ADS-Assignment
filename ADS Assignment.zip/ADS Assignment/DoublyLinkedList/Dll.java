package DoublyLinkedList;

class Dll
{
    Node head;
    int length;
    
    void inserAtBeg(int data)
    {
        
        Node newnode = new Node(data);
        if(head == null)
        {
        head = newnode;
        }
            else 
                {
                head.blink = newnode;
                newnode.flink = head;
                head = newnode;
                }
        length++;
    } 
    
    void insertAtMiddle(int pos,int data)
    {
         Node newnode = new Node(data);
        if (head==null)
        {
            head=newnode;
        }
        else
        {
          Node n=head;
          for(int i=1;i<pos-1;i++)
          {
              n=n.flink;
          }
          newnode.flink=n.flink;
          n.flink.blink=newnode;
          newnode.blink=n;
          n.flink=newnode;
         
        }
          length++;
    }
    
    void insertAtEnd(int data)
    {
        Node newnode = new Node(data);
                if(head == null)
                {
                head = newnode;
                } 
                else
                {
                Node n = head;
                while(n.flink != null) {
                        n = n.flink;    
                }       
                n.flink = newnode;
                newnode.blink = n;
                }
        length++;
}
    
   void deleteAtBeg()
   {
      
        if(head == null) 
            {
            System.out.println("list empty");
            }
        else
        {
                //Node temp = head;
                head = head.flink;
                head.blink = null;
        }
        length--;
        }
 
   void deleteAtEnd()
   {
       if(head == null)
        {
            System.out.println("list empty");
        }
       else 
       {
            Node n = head;
        while(n.flink.flink!= null)
        {
            n = n.flink;
        }
            n.flink.blink = null;
            n.flink = null;
            length--;
        }
   }
    
   void deleteAtMiddle(int pos)
   {
       if (head==null)
       {
           System.out.println("List is empty");
       }
       else
       {
           Node n=head;
           for (int i=1;i<pos-1;i++)
           {
               n=n.flink;
           }
           n.flink.flink.blink = n;
           n.flink = n.flink.flink;
           length--;
       }
   }
    
    
    

   void printforward()
    {
        Node temp=head;
        while(temp!=null)
        {
        System.out.println(temp.data);
        temp=temp.flink;
        }
    }
   
   public void displayBackward() {
        Node n = head;
        while(n.flink != null) {
                    n = n.flink;
                    }
        while(n.blink != null) {
            System.out.print(n.data + " <- ");
                    n = n.blink;
            }
            System.out.print(n.data + " ");
        }
   
    public static void main(String[] args)
    {
        Dll list = new Dll();
        list.inserAtBeg(10);
        list.insertAtEnd(20);
        list.insertAtEnd(30);
        list.insertAtEnd(50);
        list.insertAtMiddle(4,40);
    //    list.printforward();
        list.displayBackward();
      /* list.deleteAtBeg();
       list.deleteAtEnd();
       list.deleteAtMiddle();
       list.printforward();
       list.displaybackward();*/
    }
}
  