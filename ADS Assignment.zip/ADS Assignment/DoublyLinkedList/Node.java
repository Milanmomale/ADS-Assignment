package DoublyLinkedList;

class Node
{
    int data;
    Node flink;
    Node blink;
    
    Node(int data)
    {
        this.data=data;
        flink=null;
        blink=null;
    }
}