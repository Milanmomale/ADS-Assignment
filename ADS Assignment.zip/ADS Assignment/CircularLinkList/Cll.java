package CircularLinkList;

class Cll
{
    Node head;
    Node tail;
    
    void display()
    {
        Node temp=head;
        do{
        System.out.println(temp.data);
        temp=temp.next;
        } while(temp!=head);
    }

    void addFront(int data)
    {
        Node newnode =new Node(data);
        if (head==null)
        {
         head =newnode;
         tail=newnode; 
         tail.next=newnode;
        }
        else
        {
            newnode.next=head;
            tail.next=newnode;
            head=newnode;
        }
    }
 
    
    void addMiddle(int pos,int data)
    {
        Node newnode =new Node(data);
        if (head==null)
        {
         head =newnode;
         tail=newnode; 
         tail.next=newnode;
        }
        else 
        {
            Node n=head;
            for (int i=1;i<pos-1;i++)
            {
                n=n.next;
            }  
            newnode.next=n.next;
            n.next=newnode;
        }
        
    }   
 
    
    void addLast(int data)
    {
        Node newnode =new Node(data);
        if (head==null)
        {
         head =newnode;
         tail=newnode; 
         tail.next=newnode;
        }
        else
        {
            newnode.next=head;
            tail.next=newnode;
            tail=newnode;
        }
    }
  
    
    void deleteFront()
    {
        if (head==null)
        {
            System.out.println("List is empty");
        }
        else
        {
            head=head.next;
            tail.next=head;
        }
    }
    
    void deleteMiddle(int pos)
    {
        if (head==null)
        {
            System.out.println("List is empty");
        }
        else
        {
            Node n=head;
            for(int i=1;i<pos-1;i++)
            {
                n=n.next;
            }n.next=n.next.next;
            
        }
    }
    
    void deleteLast()
    {
       if (head==null)
        {
            System.out.println("List is empty");
        }
       else
       {
           Node n=head;
           while(n.next.next!=head)
           {
               n=n.next;
           }
           n.next=head;
           tail=n;
       }
    }
    
    
    
    
    
    
    
    
    
    
    public static void main(String[] args)
    {
        Cll list=new Cll();
        list.addFront(40);
        list.addFront(30);
        list.addFront(10);   
        list.addMiddle(2,20);
        list.addLast(50);
        list.addLast(60);
        list.addLast(70);
        list.display();
        System.out.println("=======================");
        list.deleteFront();
        list.display();
        System.out.println("=======================");
        list.deleteLast();
        list.display();
        System.out.println("=======================");
        list.deleteMiddle(2);
        list.display();
        System.out.println("=======================");
    }
}